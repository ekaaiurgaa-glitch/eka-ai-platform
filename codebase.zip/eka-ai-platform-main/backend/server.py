"""
EKA-AI Backend Server (Production v4.5)
Governed Automobile Intelligence System for Go4Garage Private Limited
Features: Triple-Model Router, Rate Limiting, JWT Auth, Supabase Integration, PDI Pipeline
"""

from flask import Flask, jsonify, request, send_from_directory, g
from flask_cors import CORS
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from werkzeug.middleware.proxy_fix import ProxyFix
from decimal import Decimal
from functools import wraps
import os
import json
import base64
import jwt
import datetime
import logging
from dotenv import load_dotenv

# Import EKA-AI Services
from services.mg_service import MGEngine
from services.billing import calculate_invoice_totals, validate_gstin, determine_tax_type
from middleware.auth import require_auth, get_current_user

# Import LangChain/LlamaIndex Knowledge Base and Agents
try:
    from knowledge_base.index_manager import get_knowledge_base
    from agents.rag_service import get_rag_service
    from agents.diagnostic_agent import get_diagnostic_agent
    KNOWLEDGE_BASE_AVAILABLE = True
except ImportError as e:
    logger.warning(f"⚠️ Knowledge base not available: {e}")
    KNOWLEDGE_BASE_AVAILABLE = False

load_dotenv()

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ─────────────────────────────────────────
# FLASK APP INIT
# ─────────────────────────────────────────
flask_app = Flask(__name__, static_folder='../dist', static_url_path='')

# PROXY FIX: Essential for correct IP detection behind Nginx/Emergent/AWS
flask_app.wsgi_app = ProxyFix(flask_app.wsgi_app, x_for=1, x_proto=1, x_host=1, x_prefix=1)

raw_origins = os.environ.get('CORS_ORIGINS', '*')
origins_list = [origin.strip() for origin in raw_origins.split(',') if origin.strip()]
CORS(flask_app, origins=origins_list)

# Production Rate Limiting (Redis-backed)
redis_url = os.environ.get('REDIS_URL')
if redis_url:
    limiter = Limiter(
        key_func=get_remote_address,
        app=flask_app,
        default_limits=["60 per minute"],
        storage_uri=redis_url,
        strategy="fixed-window"
    )
    logger.info("✅ Redis Rate Limiter Connected")
else:
    limiter = Limiter(
        key_func=get_remote_address,
        app=flask_app,
        default_limits=["60 per minute"],
        storage_uri="memory://"
    )
    logger.warning("⚠️ Using In-Memory Rate Limiter (Development Only)")

# ─────────────────────────────────────────
# CLIENT INITIALIZATION (Graceful Degradation)
# ─────────────────────────────────────────
supabase = None
anthropic_client = None

try:
    if os.environ.get("SUPABASE_URL"):
        from supabase import create_client
        supabase = create_client(
            os.environ.get("SUPABASE_URL"), 
            os.environ.get("SUPABASE_SERVICE_KEY")
        )
        print("✅ Supabase Connected")
except Exception as e: 
    print(f"⚠️  Supabase Warning: {e}")

try:
    if os.environ.get("ANTHROPIC_API_KEY"):
        import anthropic
        anthropic_client = anthropic.Anthropic(api_key=os.environ.get("ANTHROPIC_API_KEY"))
        print("✅ Anthropic Connected")
except Exception as e: 
    print(f"⚠️  Anthropic Warning: {e}")

# ─────────────────────────────────────────
# EKA-AI MASTER CONSTITUTION
# ─────────────────────────────────────────
EKA_CONSTITUTION = """
SYSTEM IDENTITY:
You are EKA-AI — the governed intelligence engine of Go4Garage Private Limited.
You are a deterministic, audit-grade automobile intelligence system. You are NOT a chatbot.

═══════════════════════════════════════════════════════════════
CORE CONSTITUTION (NON-NEGOTIABLE)
═══════════════════════════════════════════════════════════════

1. Single-Agent Rule: You are ONE agent. No simulated debates.
2. Zero Hallucination Rule: If confidence < 90%, ask clarifying questions. Never guess.
3. Pricing Rule (HARD BLOCK): NEVER output exact prices. Only ranges (e.g., ₹800-1200). Exact pricing lives in backend.
4. Database Authority: Prioritize injected Supabase vehicle data over user claims.
5. Safety First: Never provide unsafe repair instructions. If dangerous, say STOP.
6. Output Format: ALWAYS valid JSON. No markdown outside JSON.

═══════════════════════════════════════════════════════════════
JOB CARD LIFECYCLE (9-STATE PIPELINE)
═══════════════════════════════════════════════════════════════

STATES: CREATED → CONTEXT_VERIFIED → DIAGNOSED → ESTIMATED → CUSTOMER_APPROVAL → IN_PROGRESS → PDI → INVOICED → CLOSED

- CREATED: Intake symptoms. Do not diagnose yet.
- CONTEXT_VERIFIED: Must have Brand, Model, Year, Fuel Type.
- DIAGNOSED: Map symptoms to fault categories. Confidence gating applies.
- ESTIMATED: Price RANGES only. HSN 8708 (28% GST) for parts, 9987 (18%) for labor.
- CUSTOMER_APPROVAL: Block until explicit authorization via secure link.
- IN_PROGRESS: Workshop execution. Photo/video evidence required.
- PDI: Pre-delivery inspection checklist. Safety gates mandatory.
- INVOICED: Final billing (handled by external system).
- CLOSED: Archive. Learning ingestion allowed.

═══════════════════════════════════════════════════════════════
MG MODEL (MINIMUM GUARANTEE) — FLEET LOGIC
═══════════════════════════════════════════════════════════════

MG PURPOSE: Predictable cost exposure for fleet operators.
LOGIC: 
- Monthly_Assured_Revenue = Assured_KM × Rate_Per_KM
- Under-Utilization (Actual < Assured): Bill = Monthly_Assured_Revenue
- Over-Utilization (Actual > Assured): Bill = Assured + (Excess × Excess_Rate)
- Explain outcomes only. Never calculate final bills in text.

═══════════════════════════════════════════════════════════════
JSON OUTPUT SCHEMA (STRICT)
═══════════════════════════════════════════════════════════════
{
  "response_content": {"visual_text": "HTML/markdown string", "audio_text": "Plain text for TTS"},
  "job_status_update": "CURRENT_STATE",
  "ui_triggers": {"theme_color": "#f18a22", "show_orange_border": true},
  "diagnostic_data": {"code": "P0XXX", "severity": "CRITICAL|MODERATE|ADVISORY", "possible_causes": [], "recommended_actions": []},
  "estimate_data": {"estimate_id": "EST-XXX", "items": [], "tax_type": "CGST_SGST"},
  "mg_analysis": {"contract_status": "ACTIVE", "financial_summary": {}},
  "pdi_checklist": {"items": [], "technician_declaration": false, "evidence_provided": false},
  "recall_data": {"recalls": [], "common_issues": []}
}
"""

# ─────────────────────────────────────────
# DATABASE HELPERS
# ─────────────────────────────────────────
def fetch_vehicle_from_db(reg_number):
    """Fetch verified vehicle data from Supabase"""
    if not reg_number or not supabase: 
        return None
    try:
        res = supabase.table('vehicles').select("*").eq('registration_number', reg_number.upper()).execute()
        return res.data[0] if res.data else None
    except Exception as e: 
        print(f"DB Fetch Error: {e}")
        return None

def log_audit(mode, status, query, response, confidence=None):
    """Audit trail logging"""
    if not supabase:
        return
    try:
        supabase.table('intelligence_logs').insert({
            "mode": mode,
            "status": status,
            "user_query": query[:500],  # Truncate for safety
            "ai_response": response[:1000],
            "confidence_score": confidence,
            "created_at": datetime.datetime.now(datetime.timezone.utc).isoformat()
        }).execute()
    except Exception as e:
        print(f"Audit Log Error: {e}")

# ─────────────────────────────────────────
# AI MODEL ROUTERS
# ─────────────────────────────────────────
def call_gemini(history, system_prompt):
    """Primary Gemini Flash 2.0 Router"""
    from google import genai
    client = genai.Client(api_key=os.environ.get("GEMINI_API_KEY"))
    
    response = client.models.generate_content(
        model='gemini-2.0-flash',
        contents=history,
        config={
            "system_instruction": system_prompt, 
            "response_mime_type": "application/json",
            "temperature": 0.1
        }
    )
    return json.loads(response.text)

def call_claude(history, system_prompt):
    """Fallback Claude 3.5 Sonnet Router (for THINKING mode)"""
    # Convert Gemini format to Claude format
    messages = []
    for msg in history:
        role = "user" if msg.get("role") == "user" else "assistant"
        content = msg["parts"][0]["text"]
        messages.append({"role": role, "content": content})
    
    msg = anthropic_client.messages.create(
        model="claude-3-5-sonnet-20241022",
        max_tokens=4096,
        system=system_prompt,
        messages=messages
    )
    return json.loads(msg.content[0].text)

def normalize_response(result, default_status):
    """Ensures consistent API response shape"""
    safe_response = result if isinstance(result, dict) else {}
    return {
        "response_content": safe_response.get("response_content", {
            "visual_text": "System processed your request.", 
            "audio_text": "Processing complete."
        }),
        "job_status_update": safe_response.get("job_status_update", default_status),
        "ui_triggers": safe_response.get("ui_triggers", {
            "theme_color": "#f18a22", 
            "show_orange_border": True
        }),
        "diagnostic_data": safe_response.get("diagnostic_data"),
        "visual_metrics": safe_response.get("visual_metrics"),
        "mg_analysis": safe_response.get("mg_analysis"),
        "estimate_data": safe_response.get("estimate_data"),
        "pdi_checklist": safe_response.get("pdi_checklist"),
        "recall_data": safe_response.get("recall_data"),
        "service_history": safe_response.get("service_history")
    }

# ─────────────────────────────────────────
# API ENDPOINTS
# ─────────────────────────────────────────
@flask_app.route('/api/health')
def health():
    """System health check"""
    return jsonify({
        'status': 'healthy',
        'service': 'eka-ai-brain',
        'version': '4.5',
        'timestamp': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'integrations': {
            'supabase': supabase is not None,
            'anthropic': anthropic_client is not None,
            'gemini': os.environ.get("GEMINI_API_KEY") is not None
        }
    })

@flask_app.route('/api/chat', methods=['POST'])
@limiter.limit("15 per minute")
def chat():
    """Main intelligence endpoint"""
    try:
        data = request.get_json()
        if not data:
            return jsonify({'error': 'No data provided'}), 400
            
        history = data.get('history', [])
        context = data.get('context', {})
        status = data.get('status', 'CREATED')
        mode = data.get('intelligence_mode', 'FAST')
        op_mode = data.get('operating_mode', 0)

        # Enrich context from database
        if context.get('registrationNumber'):
            db_veh = fetch_vehicle_from_db(context['registrationNumber'])
            if db_veh: 
                context.update({
                    'brand': db_veh.get('brand', context.get('brand')),
                    'model': db_veh.get('model', context.get('model')),
                    'year': db_veh.get('year', context.get('year')),
                    'fuel_type': db_veh.get('fuel_type', context.get('fuelType')),
                    'vin': db_veh.get('vin', context.get('vin'))
                })

        system_prompt = f"{EKA_CONSTITUTION}\n[OPERATING_MODE]: {op_mode}\n[CURRENT_STATUS]: {status}\n[VEHICLE_CONTEXT]: {json.dumps(context)}"
        
        # Router Logic
        result = None
        try:
            if mode == 'THINKING' and anthropic_client:
                result = call_claude(history, system_prompt)
            else:
                result = call_gemini(history, system_prompt)
                
            # Log successful interaction
            user_query = history[-1]['parts'][0]['text'] if history else ""
            log_audit(op_mode, result.get('job_status_update', status), user_query, 
                     result.get('response_content', {}).get('visual_text', ''))
                     
        except Exception as e:
            print(f"Primary Model Error ({mode}): {e}")
            # Fallback to Gemini
            result = call_gemini(history, system_prompt)

        return jsonify(normalize_response(result, status))

    except Exception as e:
        print(f"Chat Endpoint Error: {e}")
        return jsonify({
            "response_content": {
                "visual_text": "⚠️ Governance system encountered an error. Please retry.",
                "audio_text": "System error."
            },
            "job_status_update": "CREATED",
            "ui_triggers": {"theme_color": "#FF0000", "brand_identity": "ERROR", "show_orange_border": True}
        }), 500

@flask_app.route('/api/speak', methods=['POST'])
@limiter.limit("20 per minute")
def speak():
    """Text-to-Speech using Gemini Multimodal"""
    data = request.get_json()
    text = data.get('text', '') if data else ''
    api_key = os.environ.get("GEMINI_API_KEY")
    
    if not api_key:
        return jsonify({'error': 'TTS not configured'}), 500
    
    if not text:
        return jsonify({'error': 'No text provided'}), 400
        
    try:
        from google import genai
        client = genai.Client(api_key=api_key)
        response = client.models.generate_content(
            model='gemini-2.0-flash',
            contents=text,
            config={
                "response_modalities": ["AUDIO"],
                "speech_config": {
                    "voice_config": {"prebuilt_voice_config": {"voice_name": "Kore"}}
                }
            }
        )
        for part in response.candidates[0].content.parts:
            if part.inline_data and part.inline_data.mime_type.startswith('audio/'):
                b64_audio = base64.b64encode(part.inline_data.data).decode('utf-8')
                return jsonify({'audio_data': b64_audio, 'mime_type': part.inline_data.mime_type})
        return jsonify({'error': 'No audio generated'}), 500
    except Exception as e:
        print(f"TTS Error: {e}")
        return jsonify({'error': str(e)}), 500

@flask_app.route('/api/upload-pdi', methods=['POST'])
@limiter.limit("30 per minute")
def upload_pdi():
    """PDI Evidence Upload Handler"""
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400
    
    file = request.files['file']
    job_card_id = request.form.get('job_card_id')
    checklist_item = request.form.get('checklist_item')
    
    if not file or not job_card_id or not checklist_item:
        return jsonify({'error': 'Missing required fields'}), 400
    
    if not supabase:
        return jsonify({'error': 'Storage not configured'}), 500
    
    # Validation
    allowed_extensions = {'jpg', 'jpeg', 'png', 'webp', 'mp4'}
    _, ext = os.path.splitext(file.filename)
    file_ext = ext.lstrip('.').lower() if ext else ''
    
    if file_ext not in allowed_extensions:
        return jsonify({'error': 'Invalid file type. Allowed: jpg, png, webp, mp4'}), 400
    
    # File size check (5MB)
    file.seek(0, 2)
    size = file.tell()
    file.seek(0)
    if size > 5 * 1024 * 1024:
        return jsonify({'error': 'File too large (max 5MB)'}), 400
    
    try:
        timestamp = datetime.datetime.now(datetime.timezone.utc).timestamp()
        filename = f"{job_card_id}/{checklist_item}_{timestamp}.{file_ext}"
        file_bytes = file.read()
        
        content_type = f"image/{file_ext}" if file_ext != 'mp4' else "video/mp4"
        
        supabase.storage.from_('pdi-evidence').upload(filename, file_bytes, {"content-type": content_type})
        file_url = supabase.storage.from_('pdi-evidence').get_public_url(filename)
        
        # Record in database
        supabase.table('pdi_evidence').insert({
            'job_card_id': job_card_id,
            'checklist_item': checklist_item,
            'file_url': file_url,
            'file_type': 'image' if file_ext != 'mp4' else 'video',
            'uploaded_at': datetime.datetime.now(datetime.timezone.utc).isoformat()
        }).execute()
        
        return jsonify({'success': True, 'file_url': file_url, 'filename': filename})
        
    except Exception as e:
        print(f"Upload Error: {e}")
        return jsonify({'error': 'Upload failed'}), 500

@flask_app.route('/api/approve-job', methods=['POST'])
def approve_job():
    """Customer Approval Gate with JWT"""
    data = request.get_json()
    token = data.get('token')
    action = data.get('action')  # 'approve', 'reject', 'concern'
    
    if not token or not action:
        return jsonify({'error': 'Missing token or action'}), 400
    
    if action not in {'approve', 'reject', 'concern'}:
        return jsonify({'error': 'Invalid action'}), 400
    
    jwt_secret = os.environ.get('JWT_SECRET')
    if not jwt_secret:
        return jsonify({'error': 'JWT not configured'}), 500
    
    if not supabase:
        return jsonify({'error': 'Database not configured'}), 500
    
    try:
        payload = jwt.decode(token, jwt_secret, algorithms=['HS256'])
        job_card_id = payload.get('job_card_id')
        
        status_map = {
            'approve': 'CUSTOMER_APPROVED',
            'reject': 'CREATED',
            'concern': 'CONCERN_RAISED'
        }
        new_status = status_map[action]
        
        supabase.table('job_cards').update({
            'status': new_status,
            'customer_approved_at': datetime.datetime.now(datetime.timezone.utc).isoformat() if action == 'approve' else None
        }).eq('id', job_card_id).execute()
        
        return jsonify({'success': True, 'new_status': new_status, 'job_card_id': job_card_id})
        
    except jwt.ExpiredSignatureError:
        return jsonify({'error': 'Approval link expired'}), 401
    except jwt.InvalidTokenError:
        return jsonify({'error': 'Invalid token'}), 401
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@flask_app.route('/api/generate-approval-link', methods=['POST'])
def generate_approval_link():
    """Generate secure customer approval link"""
    data = request.get_json()
    job_card_id = data.get('job_card_id')
    customer_phone = data.get('customer_phone')
    
    if not job_card_id or not customer_phone:
        return jsonify({'error': 'Missing job_card_id or customer_phone'}), 400
    
    jwt_secret = os.environ.get('JWT_SECRET')
    if not jwt_secret:
        return jsonify({'error': 'JWT not configured'}), 500
    
    if not supabase:
        return jsonify({'error': 'Database not configured'}), 500
    
    try:
        expiry = datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(hours=24)
        token = jwt.encode({
            'job_card_id': job_card_id,
            'exp': expiry,
            'phone': customer_phone
        }, jwt_secret, algorithm='HS256')
        
        supabase.table('job_cards').update({
            'approval_token': token,
            'approval_expires_at': expiry.isoformat(),
            'customer_phone': customer_phone
        }).eq('id', job_card_id).execute()
        
        base_url = os.environ.get('FRONTEND_URL', 'https://eka-ai.go4garage.in')
        approval_url = f"{base_url}/customer-approval?token={token}"
        
        return jsonify({
            'success': True,
            'approval_url': approval_url, 
            'token': token, 
            'expires_at': expiry.isoformat()
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# ═══════════════════════════════════════════════════════════════
# PHASE 2 & 3: NEW API ENDPOINTS
# ═══════════════════════════════════════════════════════════════

# ─────────────────────────────────────────
# MG FLEET ENDPOINTS
# ─────────────────────────────────────────
@flask_app.route('/api/mg/calculate', methods=['POST'])
@require_auth(allowed_roles=['OWNER', 'MANAGER', 'FLEET_MANAGER'])
def mg_calculate():
    """
    Deterministic MG Calculator.
    AI calls this tool to get 'facts', never calculates itself.
    """
    data = request.get_json()
    if not data:
        return jsonify({'error': 'No data provided'}), 400
    
    try:
        # Extract parameters with defaults
        assured_km = int(data.get('assured_km', 0))
        rate = Decimal(str(data.get('rate', 0)))
        actual_km = int(data.get('actual_km', 0))
        months = int(data.get('months_in_cycle', 1))
        excess_rate = data.get('excess_rate')
        
        if assured_km <= 0 or rate <= 0:
            return jsonify({'error': 'assured_km and rate must be positive'}), 400
        
        # Use excess calculation if excess_rate is provided
        if excess_rate is not None:
            result = MGEngine.calculate_excess_bill(
                assured_km_annual=assured_km,
                rate_per_km=rate,
                excess_rate_per_km=Decimal(str(excess_rate)),
                actual_km_run=actual_km,
                months_in_cycle=months
            )
        else:
            result = MGEngine.calculate_monthly_bill(
                assured_km_annual=assured_km,
                rate_per_km=rate,
                actual_km_run=actual_km,
                months_in_cycle=months
            )
        
        # Add audit metadata
        result['calculated_by'] = g.user_id
        result['calculated_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        
        return jsonify(result)
        
    except (ValueError, TypeError) as e:
        return jsonify({'error': f'Invalid input: {str(e)}', 'code': 'INVALID_INPUT'}), 400
    except Exception as e:
        logger.error(f"MG Calculation Error: {e}")
        return jsonify({'error': str(e), 'code': 'CALCULATION_ERROR'}), 500


@flask_app.route('/api/mg/validate-odometer', methods=['POST'])
@require_auth(allowed_roles=['OWNER', 'MANAGER', 'FLEET_MANAGER', 'TECHNICIAN'])
def mg_validate_odometer():
    """Validate odometer readings for MG vehicle logs."""
    data = request.get_json()
    if not data:
        return jsonify({'error': 'No data provided'}), 400
    
    try:
        opening = int(data.get('opening_odometer', -1))
        closing = int(data.get('closing_odometer', -1))
        
        is_valid = MGEngine.validate_odometer_reading(opening, closing)
        
        return jsonify({
            'valid': is_valid,
            'opening_odometer': opening,
            'closing_odometer': closing,
            'actual_km': closing - opening if is_valid else None,
            'message': 'Valid odometer reading' if is_valid else 'Invalid: closing must be greater than opening and both must be non-negative'
        })
        
    except (ValueError, TypeError) as e:
        return jsonify({'error': f'Invalid input: {str(e)}'}), 400


# ─────────────────────────────────────────
# JOB CARD STATE GOVERNOR
# ─────────────────────────────────────────
VALID_TRANSITIONS = {
    'CREATED': ['CONTEXT_VERIFIED'],
    'CONTEXT_VERIFIED': ['DIAGNOSED'],
    'DIAGNOSED': ['ESTIMATED'],
    'ESTIMATED': ['CUSTOMER_APPROVAL'],
    'CUSTOMER_APPROVAL': ['IN_PROGRESS', 'CONCERN_RAISED'],
    'CONCERN_RAISED': ['ESTIMATED', 'CANCELLED'],
    'IN_PROGRESS': ['PDI'],
    'PDI': ['INVOICED'],
    'INVOICED': ['CLOSED'],
    'CLOSED': [],  # Terminal state
    'CANCELLED': []  # Terminal state
}

@flask_app.route('/api/job/transition', methods=['POST'])
@require_auth()
def transition_state():
    """
    Strict State Machine Enforcer - Prevents invalid workflow jumps.
    """
    data = request.get_json()
    if not data:
        return jsonify({'error': 'No data provided'}), 400
        
    job_id = data.get('job_id')
    target_state = data.get('target_state')
    notes = data.get('notes', '')
    
    if not job_id or not target_state:
        return jsonify({'error': 'Missing job_id or target_state'}), 400
    
    if not supabase:
        return jsonify({'error': 'Database not configured'}), 500
    
    try:
        # Fetch current state from Supabase
        response = supabase.table('job_cards').select('status, workshop_id').eq('id', job_id).execute()
        if not response.data:
            return jsonify({'error': 'Job card not found'}), 404
        
        job_data = response.data[0]
        current_state = job_data['status']
        job_workshop_id = job_data.get('workshop_id')
        
        # Workshop isolation check (if workshop_id is set on job)
        if job_workshop_id and hasattr(g, 'workshop_id'):
            if g.workshop_id != job_workshop_id:
                return jsonify({'error': 'Access denied: job belongs to different workshop'}), 403
        
        # Validate transition
        allowed = VALID_TRANSITIONS.get(current_state, [])
        
        if target_state not in allowed:
            return jsonify({
                'error': 'Invalid state transition',
                'code': 'INVALID_TRANSITION',
                'current': current_state,
                'requested': target_state,
                'allowed': allowed
            }), 409
        
        # Update state with metadata
        update_data = {
            'status': target_state,
            'updated_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'updated_by': g.user_id
        }
        
        # Add state-specific timestamps
        if target_state == 'CUSTOMER_APPROVAL':
            update_data['sent_for_approval_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        elif target_state == 'IN_PROGRESS':
            update_data['started_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        elif target_state == 'CLOSED':
            update_data['closed_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        
        if notes:
            update_data['status_notes'] = notes
        
        supabase.table('job_cards').update(update_data).eq('id', job_id).execute()
        
        # Log the transition
        log_audit(
            mode=5,  # State transition mode
            status=target_state,
            query=f"Transition {job_id}: {current_state} -> {target_state}",
            response=f"Transition successful by {g.user_id}",
            confidence=1.0
        )
        
        return jsonify({
            'success': True, 
            'job_card_id': job_id,
            'previous_state': current_state,
            'new_state': target_state,
            'transitions_allowed': VALID_TRANSITIONS.get(target_state, [])
        })
        
    except Exception as e:
        logger.error(f"State Transition Error: {e}")
        return jsonify({'error': str(e), 'code': 'TRANSITION_ERROR'}), 500


@flask_app.route('/api/job/transitions', methods=['GET'])
@require_auth()
def get_valid_transitions():
    """Get valid transitions for a job card."""
    job_id = request.args.get('job_id')
    
    if not job_id:
        return jsonify({'error': 'Missing job_id parameter'}), 400
    
    if not supabase:
        return jsonify({'error': 'Database not configured'}), 500
    
    try:
        response = supabase.table('job_cards').select('status').eq('id', job_id).execute()
        if not response.data:
            return jsonify({'error': 'Job card not found'}), 404
        
        current_state = response.data[0]['status']
        allowed = VALID_TRANSITIONS.get(current_state, [])
        
        return jsonify({
            'job_card_id': job_id,
            'current_state': current_state,
            'allowed_transitions': allowed,
            'all_states': list(VALID_TRANSITIONS.keys())
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# ─────────────────────────────────────────
# BILLING & GST ENDPOINTS
# ─────────────────────────────────────────
@flask_app.route('/api/billing/calculate', methods=['POST'])
@require_auth(allowed_roles=['OWNER', 'MANAGER'])
def calculate_billing():
    """
    Calculate invoice totals with GST.
    """
    data = request.get_json()
    if not data:
        return jsonify({'error': 'No data provided'}), 400
    
    try:
        items = data.get('items', [])
        workshop_state = data.get('workshop_state', '')
        customer_state = data.get('customer_state', '')
        
        if not items:
            return jsonify({'error': 'No items provided'}), 400
        
        if not workshop_state or not customer_state:
            return jsonify({'error': 'workshop_state and customer_state are required'}), 400
        
        result = calculate_invoice_totals(items, workshop_state, customer_state)
        result['calculated_by'] = g.user_id
        result['calculated_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        
        return jsonify(result)
        
    except Exception as e:
        logger.error(f"Billing Calculation Error: {e}")
        return jsonify({'error': str(e), 'code': 'BILLING_ERROR'}), 500


@flask_app.route('/api/billing/validate-gstin', methods=['POST'])
@require_auth()
def validate_gstin_endpoint():
    """Validate GSTIN format."""
    data = request.get_json()
    if not data:
        return jsonify({'error': 'No data provided'}), 400
    
    gstin = data.get('gstin', '')
    result = validate_gstin(gstin)
    
    return jsonify(result)


@flask_app.route('/api/billing/tax-type', methods=['POST'])
@require_auth()
def get_tax_type():
    """Determine tax type based on state codes."""
    data = request.get_json()
    if not data:
        return jsonify({'error': 'No data provided'}), 400
    
    workshop_state = data.get('workshop_state', '')
    customer_state = data.get('customer_state', '')
    
    if not workshop_state or not customer_state:
        return jsonify({'error': 'workshop_state and customer_state are required'}), 400
    
    tax_type = determine_tax_type(workshop_state, customer_state)
    
    return jsonify({
        'workshop_state': workshop_state,
        'customer_state': customer_state,
        'tax_type': tax_type,
        'is_interstate': tax_type == 'IGST'
    })

# ═══════════════════════════════════════════════════════════════
# LANGCHAIN/LLAMAINDEX - KNOWLEDGE BASE & RAG ENDPOINTS
# ═══════════════════════════════════════════════════════════════

# ─────────────────────────────────────────
# KNOWLEDGE BASE MANAGEMENT
# ─────────────────────────────────────────
@flask_app.route('/api/kb/status', methods=['GET'])
@require_auth()
def kb_status():
    """Get knowledge base status and statistics"""
    if not KNOWLEDGE_BASE_AVAILABLE:
        return jsonify({
            'available': False,
            'message': 'Knowledge base service not available'
        }), 503
    
    try:
        kb = get_knowledge_base()
        stats = kb.get_stats()
        return jsonify({
            'available': True,
            'stats': stats
        })
    except Exception as e:
        logger.error(f"KB status error: {e}")
        return jsonify({'error': str(e)}), 500


@flask_app.route('/api/kb/search', methods=['POST'])
@require_auth()
def kb_search():
    """
    Search knowledge base for relevant documents
    RAG-enhanced search with semantic similarity
    """
    if not KNOWLEDGE_BASE_AVAILABLE:
        return jsonify({'error': 'Knowledge base not available'}), 503
    
    data = request.get_json()
    if not data:
        return jsonify({'error': 'No data provided'}), 400
    
    query = data.get('query', '')
    top_k = data.get('top_k', 5)
    filters = data.get('filters', None)
    
    if not query:
        return jsonify({'error': 'Query is required'}), 400
    
    try:
        kb = get_knowledge_base()
        results = kb.search(query, top_k=top_k, filters=filters)
        
        return jsonify({
            'query': query,
            'results': [
                {
                    'content': r.content,
                    'source': r.source,
                    'score': r.score,
                    'metadata': r.metadata
                }
                for r in results
            ],
            'count': len(results)
        })
        
    except Exception as e:
        logger.error(f"KB search error: {e}")
        return jsonify({'error': str(e)}), 500


@flask_app.route('/api/kb/query', methods=['POST'])
@require_auth()
def kb_query():
    """
    Query knowledge base with LLM synthesis (RAG)
    Combines retrieval with generative answering
    """
    if not KNOWLEDGE_BASE_AVAILABLE:
        return jsonify({'error': 'Knowledge base not available'}), 503
    
    data = request.get_json()
    if not data:
        return jsonify({'error': 'No data provided'}), 400
    
    query = data.get('query', '')
    vehicle_context = data.get('vehicle_context', None)
    
    if not query:
        return jsonify({'error': 'Query is required'}), 400
    
    try:
        rag = get_rag_service()
        response = rag.query(
            question=query,
            vehicle_context=vehicle_context,
            top_k=5
        )
        
        return jsonify({
            'query': query,
            'answer': response.answer,
            'sources': response.sources,
            'confidence': response.confidence,
            'tokens_used': response.tokens_used,
            'success': True
        })
        
    except Exception as e:
        logger.error(f"RAG query error: {e}")
        return jsonify({'error': str(e)}), 500


@flask_app.route('/api/kb/documents', methods=['POST'])
@require_auth(allowed_roles=['OWNER', 'MANAGER'])
def kb_add_documents():
    """
    Add documents to knowledge base
    Supports service manuals, bulletins, repair guides
    """
    if not KNOWLEDGE_BASE_AVAILABLE:
        return jsonify({'error': 'Knowledge base not available'}), 503
    
    data = request.get_json()
    if not data:
        return jsonify({'error': 'No data provided'}), 400
    
    documents = data.get('documents', [])
    source_type = data.get('source_type', 'manual')
    
    if not documents:
        return jsonify({'error': 'Documents array is required'}), 400
    
    try:
        from llama_index.core import Document
        
        kb = get_knowledge_base()
        
        # Convert to LlamaIndex documents
        idx_docs = []
        for doc in documents:
            idx_doc = Document(
                text=doc.get('content', ''),
                metadata={
                    **doc.get('metadata', {}),
                    'added_by': g.user_id,
                    'workshop_id': getattr(g, 'workshop_id', None)
                }
            )
            idx_docs.append(idx_doc)
        
        success = kb.add_documents(idx_docs, source_type)
        
        if success:
            return jsonify({
                'success': True,
                'documents_added': len(documents),
                'source_type': source_type
            })
        else:
            return jsonify({'error': 'Failed to add documents'}), 500
            
    except Exception as e:
        logger.error(f"KB add documents error: {e}")
        return jsonify({'error': str(e)}), 500


# ─────────────────────────────────────────
# DIAGNOSTIC AGENT (LangChain)
# ─────────────────────────────────────────
@flask_app.route('/api/agent/diagnose', methods=['POST'])
@require_auth()
@limiter.limit("10 per minute")
def agent_diagnose():
    """
    Intelligent diagnostic with LangChain agent
    Uses tools for knowledge retrieval and calculations
    """
    if not KNOWLEDGE_BASE_AVAILABLE:
        return jsonify({'error': 'Agent not available'}), 503
    
    data = request.get_json()
    if not data:
        return jsonify({'error': 'No data provided'}), 400
    
    symptoms = data.get('symptoms', '')
    vehicle_context = data.get('vehicle_context', {})
    chat_history = data.get('history', [])
    
    if not symptoms:
        return jsonify({'error': 'Symptoms description is required'}), 400
    
    try:
        agent = get_diagnostic_agent()
        result = agent.diagnose(
            symptoms=symptoms,
            vehicle_context=vehicle_context,
            chat_history=chat_history
        )
        
        if result['success']:
            return jsonify({
                'success': True,
                'diagnosis': result['diagnosis'],
                'tokens_used': result.get('tokens_used', 0),
                'cost': result.get('cost', 0),
                'ai_generated': True
            })
        else:
            return jsonify({
                'success': False,
                'error': result.get('error', 'Diagnosis failed')
            }), 500
            
    except Exception as e:
        logger.error(f"Agent diagnosis error: {e}")
        return jsonify({'error': str(e)}), 500


@flask_app.route('/api/agent/enhanced-chat', methods=['POST'])
@require_auth()
@limiter.limit("15 per minute")
def agent_enhanced_chat():
    """
    Enhanced chat with RAG context augmentation
    Combines traditional AI with knowledge base retrieval
    """
    if not KNOWLEDGE_BASE_AVAILABLE:
        # Fallback to regular chat
        return chat()
    
    data = request.get_json()
    if not data:
        return jsonify({'error': 'No data provided'}), 400
    
    user_message = data.get('message', '')
    vehicle_context = data.get('context', {})
    
    if not user_message:
        return jsonify({'error': 'Message is required'}), 400
    
    try:
        # First, retrieve relevant context from knowledge base
        rag = get_rag_service()
        rag_response = rag.query(
            question=user_message,
            vehicle_context=vehicle_context,
            top_k=3
        )
        
        # Augment the user message with retrieved context
        augmented_message = f"""User Question: {user_message}

Retrieved Context from Knowledge Base:
{rag_response.answer}

Sources: {', '.join([s['source'] for s in rag_response.sources[:2]])}

Please provide a comprehensive answer using the above context."""
        
        # Now call the regular chat with augmented message
        data['history'] = data.get('history', []) + [{
            'role': 'user',
            'parts': [{'text': augmented_message}]
        }]
        
        # Call existing chat endpoint logic
        return chat()
        
    except Exception as e:
        logger.error(f"Enhanced chat error: {e}")
        # Fallback to regular chat
        return chat()


# ─────────────────────────────────────────
# STATIC FILE SERVING (Production)
# ─────────────────────────────────────────
@flask_app.route('/', defaults={'path': ''})
@flask_app.route('/<path:path>')
def serve(path):
    """Serve React build files"""
    if path != "" and os.path.exists(os.path.join(flask_app.static_folder, path)):
        return send_from_directory(flask_app.static_folder, path)
    return send_from_directory(flask_app.static_folder, 'index.html')

# ─────────────────────────────────────────
# ENTRY POINT
# ─────────────────────────────────────────
if __name__ == '__main__':
    port = int(os.environ.get('PORT', 8001))
    flask_app.run(host='0.0.0.0', port=port, debug=False)
