# Knowledge Base Module for EKA-AI
# Uses LlamaIndex for document indexing and retrieval
